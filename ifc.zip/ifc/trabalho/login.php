<?php
session_start();

$mensagemErro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email_cliente'];
    $senha = $_POST['cliente_senha'];

    $usuario = buscarUsuarioPorEmail($email);

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        $_SESSION['usuario_id'] = $usuario['id'];
        header('Location: finalizar.php');
        exit();
    } else {
        $mensagemErro = "Credenciais incorretas. Deseja tentar novamente com o e-mail $email?";
    }
}

function buscarUsuarioPorEmail($email) {
    if (file_exists('clientes.json')) {
        $clientes = json_decode(file_get_contents('clientes.json'), true);
        foreach ($clientes as $id => $cliente) {
            if ($cliente['email'] === $email) {
                return [
                    'email' => $cliente['email'],
                    'senha' => $cliente['senha'],
                    'id' => $id + 1 // Usando o índice como ID
                ];
            }
        }
    }
    return null;
}
?>

<?php require_once('inc/topo.php'); ?>
<div class="main_content">
    <div class="login_register_wrap section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-md-10">
                    <div class="login_wrap">
                        <div class="padding_eight_all bg-white">
                            <div class="heading_s1">
                                <h3>Login</h3>
                            </div>
                            <?php if (!empty($mensagemErro)): ?>
                                <div class="alert alert-danger"><?php echo $mensagemErro; ?></div>
                            <?php endif; ?>
                            <form action="" method="post" name="form" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>E-mail</label>
                                    <input type="text" required="" class="form-control" name="email_cliente">
                                </div>
                                <div class="form-group">
                                    <label>Senha</label>
                                    <input class="form-control" required="" type="password" name="cliente_senha">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-fill-out btn-block" name="login">Acessar</button>
                                </div>
                            </form>
                            <div class="form-note text-center">Não tem conta? <a href="cadastro.php">Cadastre-se</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
