<html lang="en">
   <head>
        <!-- Meta -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta content="Anil z" name="author">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Script place</title>
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/animate.css">
      <!-- Latest Bootstrap min CSS -->
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/bootstrap.min.css">
      <!-- Icon Font CSS -->
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/all.min.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/ionicons.min.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/themify-icons.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/linearicons.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/flaticon.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/simple-line-icons.css">
      <!--- owl carousel CSS-->
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/owl.carousel.min.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/owl.theme.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/owl.theme.default.min.css">
      <!-- Magnific Popup CSS -->
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/magnific-popup.css">
      <!-- Slick CSS -->
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/jquery-ui.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/slick.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/slick-theme.css">
      <!-- Style CSS -->
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/style.css">
      <link rel="stylesheet" href="http://localhost/ifc/trabalho/css/responsive.css">
      <!-- Hotjar Tracking Code for bestwebcreator.com -->
   </head>
   <body class="" style="">
      <header class="header_wrap">
         <div class="middle-header dark_skin">
            <div class="container">
               <div class="nav_block">
                  <a class="navbar-brand" href="">
                  <img class="logo_light" src="http://localhost/ifc/trabalho/img/logo_topo.png" alt="logo">
                  <img class="logo_dark" src="http://localhost/ifc/trabalho/img/logo_topo.png" alt="logo">
                  </a>
               </div>
            </div>
         </div>
      </header>