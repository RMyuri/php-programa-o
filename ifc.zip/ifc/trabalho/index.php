<?php
session_start();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produto_id = $_POST['produto_id'];
    $quantidade = $_POST['quantidade'];

    // Armazena a quantidade na sessão
    $_SESSION['carrinho'][$produto_id] = $quantidade;
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$product_id = 5;
if (!isset($_SESSION['cart'][$product_id])) {
    $_SESSION['cart'][$product_id] = [
        'name' => 'Placa de Vídeo Asus Dual NVIDIA GeForce RTX 2070 EVO V2 OC Edition, 8GB, GDDR6',
        'price' => 2949.90,
        'quantity' => 0,
        'image' => 'http://localhost/ifc/trabalho/img/produto.jpg'
    ];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_quantity'])) {
        $product_id = $_POST['product_id'];
        $quantity = intval($_POST['quantity']);

        if (isset($_SESSION['cart'][$product_id])) {
            if ($quantity > 0) {
                $_SESSION['cart'][$product_id]['quantity'] = $quantity;
            } else {
                unset($_SESSION['cart'][$product_id]);
            }
        }
        exit;
    }

    if (isset($_POST['remove_product'])) {
        $product_id = $_POST['product_id'];
        if (isset($_SESSION['cart'][$product_id])) {
            unset($_SESSION['cart'][$product_id]);
        }
        exit;
    }

    if (isset($_POST['apply_coupon'])) {
        $coupon_code = trim($_POST['coupon_code']);
        if ($coupon_code == 'cupom10/10') {
            $_SESSION['discount'] = 0.10;
        } else {
            $_SESSION['discount'] = 0;
        }
        exit;
    }
}

$discount = isset($_SESSION['discount']) ? $_SESSION['discount'] : 0;
$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['quantity'];
}
$total_with_discount = $total - ($total * $discount);

require_once('inc/topo.php');
?>

<div class="main_content">
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive shop_cart_table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="product-thumbnail"></th>
                                    <th class="product-name">Produto</th>
                                    <th class="product-price">Preço</th>
                                    <th class="product-quantity">Quantidade</th>
                                    <th class="product-subtotal">Subtotal</th>
                                    <th class="product-remove">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                                <tr data-product-id="<?= $id ?>">
                                    <td class="product-thumbnail"><a href=""><img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>"></a></td>
                                    <td class="product-name" data-title="Product"><a href=""><?= $item['name'] ?></a></td>
                                    <td class="product-price" data-title="Price">R$ <?= number_format($item['price'], 2, ',', '.') ?></td>
                                    <td class="product-quantity" data-title="Quantity">
                                        <div class="quantity">
                                            <input type="button" value="-" class="qtde" tipo="menos">
                                            <input type="text" disabled="" name="qtde_pedido_item" value="<?= $item['quantity'] ?>" title="Qty" class="qty" size="4">
                                            <input type="button" value="+" class="qtde" tipo="mais">
                                        </div>
                                    </td>
                                    <td class="product-subtotal" data-title="Total">R$ <?= number_format($item['price'] * $item['quantity'], 2, ',', '.') ?></td>
                                    <td class="product-remove qtde" tipo="remove" id_produto="<?= $id ?>" data-title="Remove"><a href="#">X</a></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="6" class="px-0">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col-lg-12 col-md-12 mb-12 mb-md-12">
                                                <div class="coupon field_form input-group">
                                                    <input type="text" value="" class="form-control form-control-sm" name="coupon_code" placeholder="Código do cupom">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-fill-out btn-sm btn-apply-coupon" type="submit">Aplicar cupom</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                        <div class="cart_totals">
                            <h5>Total: R$ <?= number_format($total_with_discount, 2, ',', '.') ?></h5>
                        </div>
                        <a href="http://localhost/ifc/trabalho/login.php" class="btn btn-fill-out">Concluir compra</a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="medium_divider"></div>
                    <div class="divider center_icon"><i class="ti-shopping-cart-full"></i></div>
                    <div class="medium_divider"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $('.qtde').click(function(){
        var tipo = $(this).attr('tipo');
        var quantityInput = $(this).siblings('.qty');
        var currentQuantity = parseInt(quantityInput.val());
        var newQuantity = (tipo === 'mais') ? currentQuantity + 1 : currentQuantity - 1;

        if (newQuantity < 1) return;

        $.post('index.php', { update_quantity: true, product_id: $(this).closest('tr').data('product-id'), quantity: newQuantity }, function(response) {
            quantityInput.val(newQuantity);
            location.reload();
        });
    });

    $('.product-remove').click(function(){
        var productId = $(this).attr('id_produto');
        $.post('index.php', { remove_product: true, product_id: productId }, function(response) {
            location.reload();
        });
    });

    $('.btn-apply-coupon').click(function(){
        var couponCode = $('input[name=coupon_code]').val();
        $.post('index.php', { apply_coupon: true, coupon_code: couponCode }, function(response) {
            location.reload();
        });
    });
});
</script>
</body>
</html>
