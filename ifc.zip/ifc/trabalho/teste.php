<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capturar os dados do formulário
    $nome_cliente = $_POST['nome_cliente'];
    $sobrenome_cliente = $_POST['sobrenome_cliente'];
    $cpf_cliente = $_POST['cpf_cliente'];
    $fone_cliente = $_POST['fone_cliente'];
    $whats_cliente = $_POST['whats_cliente'];
    $email_cliente = $_POST['email_cliente'];
    $cliente_senha = password_hash($_POST['cliente_senha'], PASSWORD_DEFAULT);
    
    // Criar um array associativo com os dados do cliente
    $cliente = [
        'nome' => $nome_cliente,
        'sobrenome' => $sobrenome_cliente,
        'cpf' => $cpf_cliente,
        'telefone' => $fone_cliente,
        'whatsapp' => $whats_cliente,
        'email' => $email_cliente,
        'senha' => $cliente_senha,
    ];

    // Salvar os dados do cliente em um arquivo JSON
    $clientes = [];

    if (file_exists('clientes.json')) {
        $clientes = json_decode(file_get_contents('clientes.json'), true);
    }

    // Adicionar o novo cliente ao array de clientes
    $clientes[] = $cliente;

    // Salvar o array atualizado de clientes de volta no arquivo JSON
    file_put_contents('clientes.json', json_encode($clientes));

    // Definir uma variável de sessão para o novo usuário
    $_SESSION['usuario_id'] = rand(1, 1000); // Isso simula um ID de usuário

    // Redirecionar para a página de login
    header('Location: login.php');
    exit();
}
?>

<?php require_once('inc/topo.php'); ?>
<div class="main_content">
    <div class="login_register_wrap section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-md-10">
                    <div class="login_wrap">
                        <div class="padding_eight_all bg-white">
                            <form action="" method="post" name="form" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>Nome</label>
                                    <input type="text" required="" name="nome_cliente" id="nome_cliente" class="form-control" value="">
                                </div>
                                <div class="form-group">
                                    <label>Sobrenome</label>
                                    <input type="text" required="" name="sobrenome_cliente" id="sobrenome_cliente" class="form-control" value="">
                                </div>
                                <div class="form-group">
                                    <label>CPF</label>
                                    <input type="text" name="cpf_cliente" id="cpf_cliente" class="form-control cpf" value="" maxlength="14">
                                </div>
                                <div class="form-group">
                                    <label>Telefone</label>
                                    <input type="text" name="fone_cliente" id="fone_cliente" class="form-control fone" value="" maxlength="14">
                                </div>
                                <div class="form-group">
                                    <label>Whats</label>
                                    <input type="text" name="whats_cliente" id="whats_cliente" class="form-control fone" value="" maxlength="14">
                                </div>
                                <div class="form-group">
                                    <label>E-mail</label>
                                    <input type="email" required="" name="email_cliente" id="email_cliente" class="form-control" value="">
                                </div>
                                <div class="form-group">
                                    <label>Senha</label>
                                    <input type="password" required="" name="cliente_senha" id="cliente_senha" class="form-control" value="">
                                </div>
                                <div class="login_footer form-group">
                                    <div class="chek-form">
                                        <div class="custome-checkbox">
                                            <label><span>Ao se cadastrar você concorda com os <a href="#" style="font-weight: bold;">Termos e Condições</a></span></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-fill-out btn-block" name="register">Cadastre-se</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
