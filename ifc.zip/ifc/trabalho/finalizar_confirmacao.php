<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
 }
 
 $total = 0;
$carrinho_vazio = empty($_SESSION['cart']);
// Exemplo de dados do pedido (normalmente, esses dados seriam extraídos do banco de dados ou de uma sessão)
$pedido = [
    'data' => date('d/m/Y'), // Data do pedido atual
];

// Armazenar os dados do pedido na sessão (opcional)
$_SESSION['pedido'] = $pedido;

?>

<?php require_once('inc/topo.php'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Pedido</title>
</head>
<body>
<div class="main_content">
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive shop_cart_table">
                        <table class="table">
                         
    <h1>Detalhes do Pedido</h1>
    
    <tbody>
                    <?php if (!$carrinho_vazio): ?>
                        <?php foreach ($_SESSION['cart'] as $item): ?>
                            <?php 
                                $quantidade = $item['quantity'];
                                $preco = $item['price'];
                                $subtotal = $quantidade * $preco;
                                $total += $subtotal;
                            ?>
                    <tr>
                    <strong>Data do Pedido:</strong> <?php echo $_SESSION['pedido']['data']; ?>
                    </tr>
                    <tr>
                       <th>Produto</th>
                       <td><?php echo htmlspecialchars($item['name']); ?></td>
                     </tr>

                     <tr>
                        <th>Quantidade</th>
                        <td> <?php echo $quantidade; ?></td>
                     </tr>

                        <?php endforeach; ?>
                        <tr>
                            <td><strong>Total:</strong></td>
                            <td><strong>R$ <?php echo number_format($total, 2, ',', '.'); ?></strong></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="alert">O carrinho está vazio. Não é possível finalizar a compra.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            </table>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="medium_divider"></div>
                    <div class="divider center_icon"><i class="ti-shopping-cart-full"></i></div>
                    <div class="medium_divider"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</html>

    

