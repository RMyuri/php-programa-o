<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$error_message = "";
$login_error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $required_fields = ['nome_cliente', 'sobrenome_cliente', 'cpf_cliente', 'cep_cliente_endereco', 
                        'endereco_cliente_endereco', 'numero_cliente_endereco', 'bairro_cliente_endereco', 
                        'cod_uf', 'namo_cidade', 'fone_cliente', 'email_cliente', 'cliente_senha'];
    
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $error_message = "Por favor, preencha todos os campos obrigatórios.";
            break;
        }
    }

    if (empty($error_message)) {
        if (file_exists('clientes.json')) {
            $clientes = json_decode(file_get_contents('clientes.json'), true);
        } else {
            $clientes = [];
        }

        $email_cliente = $_POST['email_cliente'];
        $cliente_senha = $_POST['cliente_senha'];
        $usuario_encontrado = null;

        foreach ($clientes as $cliente) {
            if ($cliente['email'] === $email_cliente && password_verify($cliente_senha, $cliente['senha'])) {
                $usuario_encontrado = $cliente;
                break;
            }
        }

        if ($usuario_encontrado) {
            $_SESSION['cliente'] = [
                'nome' => $_POST['nome_cliente'],
                'sobrenome' => $_POST['sobrenome_cliente'],
                'cpf' => $_POST['cpf_cliente'],
                'cep' => $_POST['cep_cliente_endereco'],
                'endereco' => $_POST['endereco_cliente_endereco'],
                'numero' => $_POST['numero_cliente_endereco'],
                'complemento' => $_POST['complemento_cliente_endereco'],
                'bairro' => $_POST['bairro_cliente_endereco'],
                'estado' => $_POST['cod_uf'],
                'cidade' => $_POST['namo_cidade'],
                'telefone' => $_POST['fone_cliente'],
                'whatsapp' => $_POST['whats_cliente'],
                'email' => $_POST['email_cliente'],
                'observacao' => $_POST['obs_pedido']
            ];

            header('Location: finalizar_confirmacao.php');
            exit();
        } else {
            $login_error = "E-mail ou senha incorretos. Por favor, tente novamente.";
        }
    }
}

$total = 0;
$carrinho_vazio = empty($_SESSION['cart']);
?>
<?php require_once('inc/topo.php'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Finalizar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script>
        function validarQuantidade() {
            const cartItems = <?php echo json_encode($_SESSION['cart']); ?>;
            let errorMessage = "";

            cartItems.forEach(item => {
                if (item.quantity == 0) {
                    errorMessage += 'O produto "' + item.name + '" está com quantidade zero e deve ser removido ou ter a quantidade ajustada.\n';
                }
            });

            if (errorMessage) {
                document.getElementById('quantidadeErro').innerText = errorMessage;
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <div class="container mt-5">
        <form action="" method="post" enctype="multipart/form-data" onsubmit="return validarQuantidade();">
            <div class="row">
                <div class="col-md-6">
                    <h4>Detalhes de faturamento / Entrega</h4>
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($login_error)): ?>
                        <div class="alert alert-danger"><?php echo $login_error; ?></div>
                    <?php endif; ?>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="nome_cliente" placeholder="Nome *">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="sobrenome_cliente" placeholder="Sobrenome *">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="cpf_cliente" placeholder="CPF">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="cep_cliente_endereco" placeholder="CEP *" maxlength="9">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="endereco_cliente_endereco" placeholder="Endereço">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="numero_cliente_endereco" placeholder="Número *">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="complemento_cliente_endereco" placeholder="Complemento (opcional)">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="bairro_cliente_endereco" placeholder="Bairro *">
                    </div>
                    <div class="form-group">
                        <label>Estado</label>
                        <select class="form-control" required name="cod_uf">
                            <option value="">Selecione..</option>
                            <option value="AC">Acre</option>
                            <option value="AL">Alagoas</option>
                            <option value="AM">Amazonas</option>
                            <option value="AP">Amapá</option>
                            <option value="BA">Bahia</option>
                            <option value="CE">Ceará</option>
                            <option value="DF">Distrito Federal</option>
                            <option value="ES">Espírito Santo</option>
                            <option value="GO">Goiás</option>
                            <option value="MA">Maranhão</option>
                            <option value="MG">Minas Gerais</option>
                            <option value="MS">Mato Grosso do Sul</option>
                            <option value="MT">Mato Grosso</option>
                            <option value="PA">Pará</option>
                            <option value="PB">Paraíba</option>
                            <option value="PE">Pernambuco</option>
                            <option value="PI">Piauí</option>
                            <option value="PR">Paraná</option>
                            <option value="RJ">Rio de Janeiro</option>
                            <option value="RN">Rio Grande do Norte</option>
                            <option value="RO">Rondônia</option>
                            <option value="RR">Roraima</option>
                            <option value="RS">Rio Grande do Sul</option>
                            <option value="SC">Santa Catarina</option>
                            <option value="SE">Sergipe</option>
                            <option value="SP">São Paulo</option>
                            <option value="TO">Tocantins</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Cidade</label>
                        <input type="text" required class="form-control" name="namo_cidade" placeholder="Cidade">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="fone_cliente" placeholder="Telefone *">
                    </div>
                    <div class="form-group">
                        <input type="text" required class="form-control" name="whats_cliente" placeholder="WhatsApp *">
                    </div>
                    <div class="form-group">
                        <input type="email" required class="form-control" name="email_cliente" placeholder="E-mail *">
                    </div>
                    <div class="form-group">
                        <input type="password" required class="form-control" name="cliente_senha" placeholder="Senha *">
                    </div>
                    <h4>Observação</h4>
                    <div class="form-group">
                        <textarea rows="5" class="form-control" name="obs_pedido" placeholder="Observações sobre seu pedido"></textarea>
                    </div>
                </div>
                <div class="col-md-6">
                    <h4>Seu pedido</h4>
                    <div id="quantidadeErro" class="alert alert-danger" style="display: none;"></div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Produto</th>
                                <th>Quantidade</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        if (!$carrinho_vazio): 
                            foreach ($_SESSION['cart'] as $item):
                                $quantidade = $item['quantity'];
                                $preco = $item['price'];
                                $subtotal = $quantidade * $preco;
                                $total += $subtotal;
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td><?php echo $quantidade; ?></td>
                            </tr>
                        <?php endforeach; ?>
                            <tr>
                                <td style="text-align: right;"><strong>Total:</strong></td>
                                <td><strong>R$ <?php echo number_format($total, 2, ',', '.'); ?></strong></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="alert">O carrinho está vazio. Não é possível finalizar a compra.</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary btn-block" id="finalizarBtn">Finalizar</button>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
